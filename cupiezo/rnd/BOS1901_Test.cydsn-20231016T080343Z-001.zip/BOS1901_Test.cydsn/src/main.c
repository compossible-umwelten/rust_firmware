//
// Description: BOS1901 Examples
//
// Copyright (c) 2020 Boréas Technologies Inc. All rights reserved.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//

/********************************************************
*						Includes
********************************************************/
#include <stdint.h>
#include "project.h"
#include "sensing.h"
#include "driving.h"
#include "spi.h"

/********************************************************
*						DEFINES
********************************************************/


/********************************************************
*					    TYPES
********************************************************/
typedef enum {
    Examples_Sensing,       // also demonstrates driving using Fifo
    Examples_Driving       // demonstrates driving in real-time, also contains trimming example.
} Examples;

/********************************************************
*					    VARIABLES
********************************************************/
// select example to run
static Examples current_example = Examples_Driving;

/********************************************************
*						MAIN
********************************************************/
int main(void)
{	
    CyGlobalIntEnable;  // Enable global interrupts    

    spiInit();		    // Init SPI Configuration
    CyDelay(50);	    // Delay 50ms
    
    switch (current_example)
    {
        case Examples_Sensing:
            sensingFifoDriveMain();
            break;
                
        case Examples_Driving:
            sensingRealTimeDriveMain();
            break;
                
        default:
            // do nothing
            break; 
    }
}
/* [] END OF FILE */
