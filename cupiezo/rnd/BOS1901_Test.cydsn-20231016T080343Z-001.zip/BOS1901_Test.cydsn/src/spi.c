//
// Description: SPI module for Cypress MCU
//
// Copyright (c) 2019 Boréas Technologies Inc. All rights reserved.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//

#include <stdint.h>
#include "spi.h"
#include "SPIM.h"
#include "Control_Reg_1.h"


/********************************************************
*				 FUNCTIONS DEFINTION
********************************************************/

void spiInit()
{
	SPIM_Start();	// Calls SPIM_Init() and SPIM_Enable() from Cypress
	Control_Reg_1_Write(0);	// Initialize CS channel selection
}

uint8_t spiWriteVal(uint8_t channel, uint16_t value)
{
	uint8_t txStatus = SPIM_ReadTxStatus();

	// If channel doesn't exist
	if(!(channel >= 0 && channel < NB_DRIVERS_MAX))
		return SPI_TX_SEND_PROBLEM_CODE;

	// If transmit buffer is not empty
	if(!(txStatus & TX_FIFO_EMPTY_BIT))
		return SPI_TX_SEND_PROBLEM_CODE;

	// Activate the CS channel
	Control_Reg_1_Write(channel);

	// Put data in Tx buffer
	SPIM_WriteTxData(value);

	// Wait for data to be transmitted
	for(uint8_t i = 0; i < SPI_MAX_TRY; i++)
	{
		txStatus = SPIM_ReadTxStatus();
		if(txStatus & TX_SPI_DONE_BIT)
			return SPI_OK_CODE;	// Tx value sent
	}
	return SPI_TX_SEND_PROBLEM_CODE;
}

uint8_t spiReadValue(uint16_t * value)
{
	uint8_t rxStatus = SPIM_ReadRxStatus();

	// Check if buffer empty
	if(!(rxStatus & RX_FIFO_NOT_EMPTY))
	{
		// Empty
		return SPI_RX_EMPTY_CODE;
	}
	else
	{
		// Not empty
		*value = SPIM_ReadRxData();
	}

	return SPI_OK_CODE;
}

// Writes data to SPI and reads returned data
uint16_t spiReadWriteReg(uint8_t chipSelect, uint16_t data)
{
    uint16_t d = 0x0;

	spiWriteVal(chipSelect, data);
    
	spiReadValue(&d);
	
	return d;
}

bool spiEmptyRxBuffer()
{
	uint16_t value;

	for(uint8_t i = 0; i < SPI_MAX_TRY; i++)
	{
		if(spiReadValue(&value) == SPI_RX_EMPTY_CODE)
			return true;
	}

	return false;
}

/* [] END OF FILE */
