/*******************************************************************************
* File Name: son_31.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_son_31_H) /* Pins son_31_H */
#define CY_PINS_son_31_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "son_31_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 son_31__PORT == 15 && ((son_31__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    son_31_Write(uint8 value);
void    son_31_SetDriveMode(uint8 mode);
uint8   son_31_ReadDataReg(void);
uint8   son_31_Read(void);
void    son_31_SetInterruptMode(uint16 position, uint16 mode);
uint8   son_31_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the son_31_SetDriveMode() function.
     *  @{
     */
        #define son_31_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define son_31_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define son_31_DM_RES_UP          PIN_DM_RES_UP
        #define son_31_DM_RES_DWN         PIN_DM_RES_DWN
        #define son_31_DM_OD_LO           PIN_DM_OD_LO
        #define son_31_DM_OD_HI           PIN_DM_OD_HI
        #define son_31_DM_STRONG          PIN_DM_STRONG
        #define son_31_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define son_31_MASK               son_31__MASK
#define son_31_SHIFT              son_31__SHIFT
#define son_31_WIDTH              1u

/* Interrupt constants */
#if defined(son_31__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in son_31_SetInterruptMode() function.
     *  @{
     */
        #define son_31_INTR_NONE      (uint16)(0x0000u)
        #define son_31_INTR_RISING    (uint16)(0x0001u)
        #define son_31_INTR_FALLING   (uint16)(0x0002u)
        #define son_31_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define son_31_INTR_MASK      (0x01u) 
#endif /* (son_31__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define son_31_PS                     (* (reg8 *) son_31__PS)
/* Data Register */
#define son_31_DR                     (* (reg8 *) son_31__DR)
/* Port Number */
#define son_31_PRT_NUM                (* (reg8 *) son_31__PRT) 
/* Connect to Analog Globals */                                                  
#define son_31_AG                     (* (reg8 *) son_31__AG)                       
/* Analog MUX bux enable */
#define son_31_AMUX                   (* (reg8 *) son_31__AMUX) 
/* Bidirectional Enable */                                                        
#define son_31_BIE                    (* (reg8 *) son_31__BIE)
/* Bit-mask for Aliased Register Access */
#define son_31_BIT_MASK               (* (reg8 *) son_31__BIT_MASK)
/* Bypass Enable */
#define son_31_BYP                    (* (reg8 *) son_31__BYP)
/* Port wide control signals */                                                   
#define son_31_CTL                    (* (reg8 *) son_31__CTL)
/* Drive Modes */
#define son_31_DM0                    (* (reg8 *) son_31__DM0) 
#define son_31_DM1                    (* (reg8 *) son_31__DM1)
#define son_31_DM2                    (* (reg8 *) son_31__DM2) 
/* Input Buffer Disable Override */
#define son_31_INP_DIS                (* (reg8 *) son_31__INP_DIS)
/* LCD Common or Segment Drive */
#define son_31_LCD_COM_SEG            (* (reg8 *) son_31__LCD_COM_SEG)
/* Enable Segment LCD */
#define son_31_LCD_EN                 (* (reg8 *) son_31__LCD_EN)
/* Slew Rate Control */
#define son_31_SLW                    (* (reg8 *) son_31__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define son_31_PRTDSI__CAPS_SEL       (* (reg8 *) son_31__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define son_31_PRTDSI__DBL_SYNC_IN    (* (reg8 *) son_31__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define son_31_PRTDSI__OE_SEL0        (* (reg8 *) son_31__PRTDSI__OE_SEL0) 
#define son_31_PRTDSI__OE_SEL1        (* (reg8 *) son_31__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define son_31_PRTDSI__OUT_SEL0       (* (reg8 *) son_31__PRTDSI__OUT_SEL0) 
#define son_31_PRTDSI__OUT_SEL1       (* (reg8 *) son_31__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define son_31_PRTDSI__SYNC_OUT       (* (reg8 *) son_31__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(son_31__SIO_CFG)
    #define son_31_SIO_HYST_EN        (* (reg8 *) son_31__SIO_HYST_EN)
    #define son_31_SIO_REG_HIFREQ     (* (reg8 *) son_31__SIO_REG_HIFREQ)
    #define son_31_SIO_CFG            (* (reg8 *) son_31__SIO_CFG)
    #define son_31_SIO_DIFF           (* (reg8 *) son_31__SIO_DIFF)
#endif /* (son_31__SIO_CFG) */

/* Interrupt Registers */
#if defined(son_31__INTSTAT)
    #define son_31_INTSTAT            (* (reg8 *) son_31__INTSTAT)
    #define son_31_SNAP               (* (reg8 *) son_31__SNAP)
    
	#define son_31_0_INTTYPE_REG 		(* (reg8 *) son_31__0__INTTYPE)
#endif /* (son_31__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_son_31_H */


/* [] END OF FILE */
