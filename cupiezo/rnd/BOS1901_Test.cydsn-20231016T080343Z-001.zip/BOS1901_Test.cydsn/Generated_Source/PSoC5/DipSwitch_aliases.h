/*******************************************************************************
* File Name: DipSwitch.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DipSwitch_ALIASES_H) /* Pins DipSwitch_ALIASES_H */
#define CY_PINS_DipSwitch_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define DipSwitch_0			(DipSwitch__0__PC)
#define DipSwitch_0_INTR	((uint16)((uint16)0x0001u << DipSwitch__0__SHIFT))

#define DipSwitch_1			(DipSwitch__1__PC)
#define DipSwitch_1_INTR	((uint16)((uint16)0x0001u << DipSwitch__1__SHIFT))

#define DipSwitch_2			(DipSwitch__2__PC)
#define DipSwitch_2_INTR	((uint16)((uint16)0x0001u << DipSwitch__2__SHIFT))

#define DipSwitch_3			(DipSwitch__3__PC)
#define DipSwitch_3_INTR	((uint16)((uint16)0x0001u << DipSwitch__3__SHIFT))

#define DipSwitch_4			(DipSwitch__4__PC)
#define DipSwitch_4_INTR	((uint16)((uint16)0x0001u << DipSwitch__4__SHIFT))

#define DipSwitch_5			(DipSwitch__5__PC)
#define DipSwitch_5_INTR	((uint16)((uint16)0x0001u << DipSwitch__5__SHIFT))

#define DipSwitch_6			(DipSwitch__6__PC)
#define DipSwitch_6_INTR	((uint16)((uint16)0x0001u << DipSwitch__6__SHIFT))

#define DipSwitch_7			(DipSwitch__7__PC)
#define DipSwitch_7_INTR	((uint16)((uint16)0x0001u << DipSwitch__7__SHIFT))

#define DipSwitch_INTR_ALL	 ((uint16)(DipSwitch_0_INTR| DipSwitch_1_INTR| DipSwitch_2_INTR| DipSwitch_3_INTR| DipSwitch_4_INTR| DipSwitch_5_INTR| DipSwitch_6_INTR| DipSwitch_7_INTR))

#endif /* End Pins DipSwitch_ALIASES_H */


/* [] END OF FILE */
