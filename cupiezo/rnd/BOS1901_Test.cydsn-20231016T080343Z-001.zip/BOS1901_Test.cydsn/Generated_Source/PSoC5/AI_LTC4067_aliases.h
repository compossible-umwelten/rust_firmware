/*******************************************************************************
* File Name: AI_LTC4067.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_AI_LTC4067_ALIASES_H) /* Pins AI_LTC4067_ALIASES_H */
#define CY_PINS_AI_LTC4067_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define AI_LTC4067_0			(AI_LTC4067__0__PC)
#define AI_LTC4067_0_INTR	((uint16)((uint16)0x0001u << AI_LTC4067__0__SHIFT))

#define AI_LTC4067_1			(AI_LTC4067__1__PC)
#define AI_LTC4067_1_INTR	((uint16)((uint16)0x0001u << AI_LTC4067__1__SHIFT))

#define AI_LTC4067_2			(AI_LTC4067__2__PC)
#define AI_LTC4067_2_INTR	((uint16)((uint16)0x0001u << AI_LTC4067__2__SHIFT))

#define AI_LTC4067_INTR_ALL	 ((uint16)(AI_LTC4067_0_INTR| AI_LTC4067_1_INTR| AI_LTC4067_2_INTR))

#endif /* End Pins AI_LTC4067_ALIASES_H */


/* [] END OF FILE */
