/*******************************************************************************
* File Name: sck.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_sck_H) /* Pins sck_H */
#define CY_PINS_sck_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "sck_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 sck__PORT == 15 && ((sck__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    sck_Write(uint8 value);
void    sck_SetDriveMode(uint8 mode);
uint8   sck_ReadDataReg(void);
uint8   sck_Read(void);
void    sck_SetInterruptMode(uint16 position, uint16 mode);
uint8   sck_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the sck_SetDriveMode() function.
     *  @{
     */
        #define sck_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define sck_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define sck_DM_RES_UP          PIN_DM_RES_UP
        #define sck_DM_RES_DWN         PIN_DM_RES_DWN
        #define sck_DM_OD_LO           PIN_DM_OD_LO
        #define sck_DM_OD_HI           PIN_DM_OD_HI
        #define sck_DM_STRONG          PIN_DM_STRONG
        #define sck_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define sck_MASK               sck__MASK
#define sck_SHIFT              sck__SHIFT
#define sck_WIDTH              1u

/* Interrupt constants */
#if defined(sck__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in sck_SetInterruptMode() function.
     *  @{
     */
        #define sck_INTR_NONE      (uint16)(0x0000u)
        #define sck_INTR_RISING    (uint16)(0x0001u)
        #define sck_INTR_FALLING   (uint16)(0x0002u)
        #define sck_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define sck_INTR_MASK      (0x01u) 
#endif /* (sck__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define sck_PS                     (* (reg8 *) sck__PS)
/* Data Register */
#define sck_DR                     (* (reg8 *) sck__DR)
/* Port Number */
#define sck_PRT_NUM                (* (reg8 *) sck__PRT) 
/* Connect to Analog Globals */                                                  
#define sck_AG                     (* (reg8 *) sck__AG)                       
/* Analog MUX bux enable */
#define sck_AMUX                   (* (reg8 *) sck__AMUX) 
/* Bidirectional Enable */                                                        
#define sck_BIE                    (* (reg8 *) sck__BIE)
/* Bit-mask for Aliased Register Access */
#define sck_BIT_MASK               (* (reg8 *) sck__BIT_MASK)
/* Bypass Enable */
#define sck_BYP                    (* (reg8 *) sck__BYP)
/* Port wide control signals */                                                   
#define sck_CTL                    (* (reg8 *) sck__CTL)
/* Drive Modes */
#define sck_DM0                    (* (reg8 *) sck__DM0) 
#define sck_DM1                    (* (reg8 *) sck__DM1)
#define sck_DM2                    (* (reg8 *) sck__DM2) 
/* Input Buffer Disable Override */
#define sck_INP_DIS                (* (reg8 *) sck__INP_DIS)
/* LCD Common or Segment Drive */
#define sck_LCD_COM_SEG            (* (reg8 *) sck__LCD_COM_SEG)
/* Enable Segment LCD */
#define sck_LCD_EN                 (* (reg8 *) sck__LCD_EN)
/* Slew Rate Control */
#define sck_SLW                    (* (reg8 *) sck__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define sck_PRTDSI__CAPS_SEL       (* (reg8 *) sck__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define sck_PRTDSI__DBL_SYNC_IN    (* (reg8 *) sck__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define sck_PRTDSI__OE_SEL0        (* (reg8 *) sck__PRTDSI__OE_SEL0) 
#define sck_PRTDSI__OE_SEL1        (* (reg8 *) sck__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define sck_PRTDSI__OUT_SEL0       (* (reg8 *) sck__PRTDSI__OUT_SEL0) 
#define sck_PRTDSI__OUT_SEL1       (* (reg8 *) sck__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define sck_PRTDSI__SYNC_OUT       (* (reg8 *) sck__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(sck__SIO_CFG)
    #define sck_SIO_HYST_EN        (* (reg8 *) sck__SIO_HYST_EN)
    #define sck_SIO_REG_HIFREQ     (* (reg8 *) sck__SIO_REG_HIFREQ)
    #define sck_SIO_CFG            (* (reg8 *) sck__SIO_CFG)
    #define sck_SIO_DIFF           (* (reg8 *) sck__SIO_DIFF)
#endif /* (sck__SIO_CFG) */

/* Interrupt Registers */
#if defined(sck__INTSTAT)
    #define sck_INTSTAT            (* (reg8 *) sck__INTSTAT)
    #define sck_SNAP               (* (reg8 *) sck__SNAP)
    
	#define sck_0_INTTYPE_REG 		(* (reg8 *) sck__0__INTTYPE)
#endif /* (sck__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_sck_H */


/* [] END OF FILE */
