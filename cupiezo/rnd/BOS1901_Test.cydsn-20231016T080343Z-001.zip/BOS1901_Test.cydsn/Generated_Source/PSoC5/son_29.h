/*******************************************************************************
* File Name: son_29.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_son_29_H) /* Pins son_29_H */
#define CY_PINS_son_29_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "son_29_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 son_29__PORT == 15 && ((son_29__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    son_29_Write(uint8 value);
void    son_29_SetDriveMode(uint8 mode);
uint8   son_29_ReadDataReg(void);
uint8   son_29_Read(void);
void    son_29_SetInterruptMode(uint16 position, uint16 mode);
uint8   son_29_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the son_29_SetDriveMode() function.
     *  @{
     */
        #define son_29_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define son_29_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define son_29_DM_RES_UP          PIN_DM_RES_UP
        #define son_29_DM_RES_DWN         PIN_DM_RES_DWN
        #define son_29_DM_OD_LO           PIN_DM_OD_LO
        #define son_29_DM_OD_HI           PIN_DM_OD_HI
        #define son_29_DM_STRONG          PIN_DM_STRONG
        #define son_29_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define son_29_MASK               son_29__MASK
#define son_29_SHIFT              son_29__SHIFT
#define son_29_WIDTH              1u

/* Interrupt constants */
#if defined(son_29__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in son_29_SetInterruptMode() function.
     *  @{
     */
        #define son_29_INTR_NONE      (uint16)(0x0000u)
        #define son_29_INTR_RISING    (uint16)(0x0001u)
        #define son_29_INTR_FALLING   (uint16)(0x0002u)
        #define son_29_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define son_29_INTR_MASK      (0x01u) 
#endif /* (son_29__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define son_29_PS                     (* (reg8 *) son_29__PS)
/* Data Register */
#define son_29_DR                     (* (reg8 *) son_29__DR)
/* Port Number */
#define son_29_PRT_NUM                (* (reg8 *) son_29__PRT) 
/* Connect to Analog Globals */                                                  
#define son_29_AG                     (* (reg8 *) son_29__AG)                       
/* Analog MUX bux enable */
#define son_29_AMUX                   (* (reg8 *) son_29__AMUX) 
/* Bidirectional Enable */                                                        
#define son_29_BIE                    (* (reg8 *) son_29__BIE)
/* Bit-mask for Aliased Register Access */
#define son_29_BIT_MASK               (* (reg8 *) son_29__BIT_MASK)
/* Bypass Enable */
#define son_29_BYP                    (* (reg8 *) son_29__BYP)
/* Port wide control signals */                                                   
#define son_29_CTL                    (* (reg8 *) son_29__CTL)
/* Drive Modes */
#define son_29_DM0                    (* (reg8 *) son_29__DM0) 
#define son_29_DM1                    (* (reg8 *) son_29__DM1)
#define son_29_DM2                    (* (reg8 *) son_29__DM2) 
/* Input Buffer Disable Override */
#define son_29_INP_DIS                (* (reg8 *) son_29__INP_DIS)
/* LCD Common or Segment Drive */
#define son_29_LCD_COM_SEG            (* (reg8 *) son_29__LCD_COM_SEG)
/* Enable Segment LCD */
#define son_29_LCD_EN                 (* (reg8 *) son_29__LCD_EN)
/* Slew Rate Control */
#define son_29_SLW                    (* (reg8 *) son_29__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define son_29_PRTDSI__CAPS_SEL       (* (reg8 *) son_29__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define son_29_PRTDSI__DBL_SYNC_IN    (* (reg8 *) son_29__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define son_29_PRTDSI__OE_SEL0        (* (reg8 *) son_29__PRTDSI__OE_SEL0) 
#define son_29_PRTDSI__OE_SEL1        (* (reg8 *) son_29__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define son_29_PRTDSI__OUT_SEL0       (* (reg8 *) son_29__PRTDSI__OUT_SEL0) 
#define son_29_PRTDSI__OUT_SEL1       (* (reg8 *) son_29__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define son_29_PRTDSI__SYNC_OUT       (* (reg8 *) son_29__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(son_29__SIO_CFG)
    #define son_29_SIO_HYST_EN        (* (reg8 *) son_29__SIO_HYST_EN)
    #define son_29_SIO_REG_HIFREQ     (* (reg8 *) son_29__SIO_REG_HIFREQ)
    #define son_29_SIO_CFG            (* (reg8 *) son_29__SIO_CFG)
    #define son_29_SIO_DIFF           (* (reg8 *) son_29__SIO_DIFF)
#endif /* (son_29__SIO_CFG) */

/* Interrupt Registers */
#if defined(son_29__INTSTAT)
    #define son_29_INTSTAT            (* (reg8 *) son_29__INTSTAT)
    #define son_29_SNAP               (* (reg8 *) son_29__SNAP)
    
	#define son_29_0_INTTYPE_REG 		(* (reg8 *) son_29__0__INTTYPE)
#endif /* (son_29__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_son_29_H */


/* [] END OF FILE */
