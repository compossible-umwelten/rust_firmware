/*******************************************************************************
* File Name: BSel.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_BSel_H) /* Pins BSel_H */
#define CY_PINS_BSel_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "BSel_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 BSel__PORT == 15 && ((BSel__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    BSel_Write(uint8 value);
void    BSel_SetDriveMode(uint8 mode);
uint8   BSel_ReadDataReg(void);
uint8   BSel_Read(void);
void    BSel_SetInterruptMode(uint16 position, uint16 mode);
uint8   BSel_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the BSel_SetDriveMode() function.
     *  @{
     */
        #define BSel_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define BSel_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define BSel_DM_RES_UP          PIN_DM_RES_UP
        #define BSel_DM_RES_DWN         PIN_DM_RES_DWN
        #define BSel_DM_OD_LO           PIN_DM_OD_LO
        #define BSel_DM_OD_HI           PIN_DM_OD_HI
        #define BSel_DM_STRONG          PIN_DM_STRONG
        #define BSel_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define BSel_MASK               BSel__MASK
#define BSel_SHIFT              BSel__SHIFT
#define BSel_WIDTH              1u

/* Interrupt constants */
#if defined(BSel__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in BSel_SetInterruptMode() function.
     *  @{
     */
        #define BSel_INTR_NONE      (uint16)(0x0000u)
        #define BSel_INTR_RISING    (uint16)(0x0001u)
        #define BSel_INTR_FALLING   (uint16)(0x0002u)
        #define BSel_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define BSel_INTR_MASK      (0x01u) 
#endif /* (BSel__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define BSel_PS                     (* (reg8 *) BSel__PS)
/* Data Register */
#define BSel_DR                     (* (reg8 *) BSel__DR)
/* Port Number */
#define BSel_PRT_NUM                (* (reg8 *) BSel__PRT) 
/* Connect to Analog Globals */                                                  
#define BSel_AG                     (* (reg8 *) BSel__AG)                       
/* Analog MUX bux enable */
#define BSel_AMUX                   (* (reg8 *) BSel__AMUX) 
/* Bidirectional Enable */                                                        
#define BSel_BIE                    (* (reg8 *) BSel__BIE)
/* Bit-mask for Aliased Register Access */
#define BSel_BIT_MASK               (* (reg8 *) BSel__BIT_MASK)
/* Bypass Enable */
#define BSel_BYP                    (* (reg8 *) BSel__BYP)
/* Port wide control signals */                                                   
#define BSel_CTL                    (* (reg8 *) BSel__CTL)
/* Drive Modes */
#define BSel_DM0                    (* (reg8 *) BSel__DM0) 
#define BSel_DM1                    (* (reg8 *) BSel__DM1)
#define BSel_DM2                    (* (reg8 *) BSel__DM2) 
/* Input Buffer Disable Override */
#define BSel_INP_DIS                (* (reg8 *) BSel__INP_DIS)
/* LCD Common or Segment Drive */
#define BSel_LCD_COM_SEG            (* (reg8 *) BSel__LCD_COM_SEG)
/* Enable Segment LCD */
#define BSel_LCD_EN                 (* (reg8 *) BSel__LCD_EN)
/* Slew Rate Control */
#define BSel_SLW                    (* (reg8 *) BSel__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define BSel_PRTDSI__CAPS_SEL       (* (reg8 *) BSel__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define BSel_PRTDSI__DBL_SYNC_IN    (* (reg8 *) BSel__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define BSel_PRTDSI__OE_SEL0        (* (reg8 *) BSel__PRTDSI__OE_SEL0) 
#define BSel_PRTDSI__OE_SEL1        (* (reg8 *) BSel__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define BSel_PRTDSI__OUT_SEL0       (* (reg8 *) BSel__PRTDSI__OUT_SEL0) 
#define BSel_PRTDSI__OUT_SEL1       (* (reg8 *) BSel__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define BSel_PRTDSI__SYNC_OUT       (* (reg8 *) BSel__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(BSel__SIO_CFG)
    #define BSel_SIO_HYST_EN        (* (reg8 *) BSel__SIO_HYST_EN)
    #define BSel_SIO_REG_HIFREQ     (* (reg8 *) BSel__SIO_REG_HIFREQ)
    #define BSel_SIO_CFG            (* (reg8 *) BSel__SIO_CFG)
    #define BSel_SIO_DIFF           (* (reg8 *) BSel__SIO_DIFF)
#endif /* (BSel__SIO_CFG) */

/* Interrupt Registers */
#if defined(BSel__INTSTAT)
    #define BSel_INTSTAT            (* (reg8 *) BSel__INTSTAT)
    #define BSel_SNAP               (* (reg8 *) BSel__SNAP)
    
	#define BSel_0_INTTYPE_REG 		(* (reg8 *) BSel__0__INTTYPE)
#endif /* (BSel__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_BSel_H */


/* [] END OF FILE */
