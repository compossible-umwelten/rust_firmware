/*******************************************************************************
* File Name: TimerHandler.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_TimerHandler_H)
#define CY_ISR_TimerHandler_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void TimerHandler_Start(void);
void TimerHandler_StartEx(cyisraddress address);
void TimerHandler_Stop(void);

CY_ISR_PROTO(TimerHandler_Interrupt);

void TimerHandler_SetVector(cyisraddress address);
cyisraddress TimerHandler_GetVector(void);

void TimerHandler_SetPriority(uint8 priority);
uint8 TimerHandler_GetPriority(void);

void TimerHandler_Enable(void);
uint8 TimerHandler_GetState(void);
void TimerHandler_Disable(void);

void TimerHandler_SetPending(void);
void TimerHandler_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the TimerHandler ISR. */
#define TimerHandler_INTC_VECTOR            ((reg32 *) TimerHandler__INTC_VECT)

/* Address of the TimerHandler ISR priority. */
#define TimerHandler_INTC_PRIOR             ((reg8 *) TimerHandler__INTC_PRIOR_REG)

/* Priority of the TimerHandler interrupt. */
#define TimerHandler_INTC_PRIOR_NUMBER      TimerHandler__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable TimerHandler interrupt. */
#define TimerHandler_INTC_SET_EN            ((reg32 *) TimerHandler__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the TimerHandler interrupt. */
#define TimerHandler_INTC_CLR_EN            ((reg32 *) TimerHandler__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the TimerHandler interrupt state to pending. */
#define TimerHandler_INTC_SET_PD            ((reg32 *) TimerHandler__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the TimerHandler interrupt. */
#define TimerHandler_INTC_CLR_PD            ((reg32 *) TimerHandler__INTC_CLR_PD_REG)


#endif /* CY_ISR_TimerHandler_H */


/* [] END OF FILE */
