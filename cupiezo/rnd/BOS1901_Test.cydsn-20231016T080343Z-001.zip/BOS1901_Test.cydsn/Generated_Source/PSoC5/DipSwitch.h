/*******************************************************************************
* File Name: DipSwitch.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DipSwitch_H) /* Pins DipSwitch_H */
#define CY_PINS_DipSwitch_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "DipSwitch_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 DipSwitch__PORT == 15 && ((DipSwitch__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    DipSwitch_Write(uint8 value);
void    DipSwitch_SetDriveMode(uint8 mode);
uint8   DipSwitch_ReadDataReg(void);
uint8   DipSwitch_Read(void);
void    DipSwitch_SetInterruptMode(uint16 position, uint16 mode);
uint8   DipSwitch_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the DipSwitch_SetDriveMode() function.
     *  @{
     */
        #define DipSwitch_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define DipSwitch_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define DipSwitch_DM_RES_UP          PIN_DM_RES_UP
        #define DipSwitch_DM_RES_DWN         PIN_DM_RES_DWN
        #define DipSwitch_DM_OD_LO           PIN_DM_OD_LO
        #define DipSwitch_DM_OD_HI           PIN_DM_OD_HI
        #define DipSwitch_DM_STRONG          PIN_DM_STRONG
        #define DipSwitch_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define DipSwitch_MASK               DipSwitch__MASK
#define DipSwitch_SHIFT              DipSwitch__SHIFT
#define DipSwitch_WIDTH              8u

/* Interrupt constants */
#if defined(DipSwitch__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in DipSwitch_SetInterruptMode() function.
     *  @{
     */
        #define DipSwitch_INTR_NONE      (uint16)(0x0000u)
        #define DipSwitch_INTR_RISING    (uint16)(0x0001u)
        #define DipSwitch_INTR_FALLING   (uint16)(0x0002u)
        #define DipSwitch_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define DipSwitch_INTR_MASK      (0x01u) 
#endif /* (DipSwitch__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define DipSwitch_PS                     (* (reg8 *) DipSwitch__PS)
/* Data Register */
#define DipSwitch_DR                     (* (reg8 *) DipSwitch__DR)
/* Port Number */
#define DipSwitch_PRT_NUM                (* (reg8 *) DipSwitch__PRT) 
/* Connect to Analog Globals */                                                  
#define DipSwitch_AG                     (* (reg8 *) DipSwitch__AG)                       
/* Analog MUX bux enable */
#define DipSwitch_AMUX                   (* (reg8 *) DipSwitch__AMUX) 
/* Bidirectional Enable */                                                        
#define DipSwitch_BIE                    (* (reg8 *) DipSwitch__BIE)
/* Bit-mask for Aliased Register Access */
#define DipSwitch_BIT_MASK               (* (reg8 *) DipSwitch__BIT_MASK)
/* Bypass Enable */
#define DipSwitch_BYP                    (* (reg8 *) DipSwitch__BYP)
/* Port wide control signals */                                                   
#define DipSwitch_CTL                    (* (reg8 *) DipSwitch__CTL)
/* Drive Modes */
#define DipSwitch_DM0                    (* (reg8 *) DipSwitch__DM0) 
#define DipSwitch_DM1                    (* (reg8 *) DipSwitch__DM1)
#define DipSwitch_DM2                    (* (reg8 *) DipSwitch__DM2) 
/* Input Buffer Disable Override */
#define DipSwitch_INP_DIS                (* (reg8 *) DipSwitch__INP_DIS)
/* LCD Common or Segment Drive */
#define DipSwitch_LCD_COM_SEG            (* (reg8 *) DipSwitch__LCD_COM_SEG)
/* Enable Segment LCD */
#define DipSwitch_LCD_EN                 (* (reg8 *) DipSwitch__LCD_EN)
/* Slew Rate Control */
#define DipSwitch_SLW                    (* (reg8 *) DipSwitch__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define DipSwitch_PRTDSI__CAPS_SEL       (* (reg8 *) DipSwitch__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define DipSwitch_PRTDSI__DBL_SYNC_IN    (* (reg8 *) DipSwitch__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define DipSwitch_PRTDSI__OE_SEL0        (* (reg8 *) DipSwitch__PRTDSI__OE_SEL0) 
#define DipSwitch_PRTDSI__OE_SEL1        (* (reg8 *) DipSwitch__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define DipSwitch_PRTDSI__OUT_SEL0       (* (reg8 *) DipSwitch__PRTDSI__OUT_SEL0) 
#define DipSwitch_PRTDSI__OUT_SEL1       (* (reg8 *) DipSwitch__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define DipSwitch_PRTDSI__SYNC_OUT       (* (reg8 *) DipSwitch__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(DipSwitch__SIO_CFG)
    #define DipSwitch_SIO_HYST_EN        (* (reg8 *) DipSwitch__SIO_HYST_EN)
    #define DipSwitch_SIO_REG_HIFREQ     (* (reg8 *) DipSwitch__SIO_REG_HIFREQ)
    #define DipSwitch_SIO_CFG            (* (reg8 *) DipSwitch__SIO_CFG)
    #define DipSwitch_SIO_DIFF           (* (reg8 *) DipSwitch__SIO_DIFF)
#endif /* (DipSwitch__SIO_CFG) */

/* Interrupt Registers */
#if defined(DipSwitch__INTSTAT)
    #define DipSwitch_INTSTAT            (* (reg8 *) DipSwitch__INTSTAT)
    #define DipSwitch_SNAP               (* (reg8 *) DipSwitch__SNAP)
    
	#define DipSwitch_0_INTTYPE_REG 		(* (reg8 *) DipSwitch__0__INTTYPE)
	#define DipSwitch_1_INTTYPE_REG 		(* (reg8 *) DipSwitch__1__INTTYPE)
	#define DipSwitch_2_INTTYPE_REG 		(* (reg8 *) DipSwitch__2__INTTYPE)
	#define DipSwitch_3_INTTYPE_REG 		(* (reg8 *) DipSwitch__3__INTTYPE)
	#define DipSwitch_4_INTTYPE_REG 		(* (reg8 *) DipSwitch__4__INTTYPE)
	#define DipSwitch_5_INTTYPE_REG 		(* (reg8 *) DipSwitch__5__INTTYPE)
	#define DipSwitch_6_INTTYPE_REG 		(* (reg8 *) DipSwitch__6__INTTYPE)
	#define DipSwitch_7_INTTYPE_REG 		(* (reg8 *) DipSwitch__7__INTTYPE)
#endif /* (DipSwitch__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_DipSwitch_H */


/* [] END OF FILE */
