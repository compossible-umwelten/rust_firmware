//
// Description: SPI module for Cypress MCU
//
// Copyright (c) 2019 Boréas Technologies Inc. All rights reserved.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//

#ifndef __SPI_H__
#define __SPI_H__

#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#include "project.h"

/********************************************************
*						DEFINES
********************************************************/
    
#define TX_SPI_DONE_BIT			(0x1)		// bit 0
#define TX_FIFO_EMPTY_BIT		(0x2)		// bit 1
#define TX_FIFO_NOT_FULL_BIT	(0x4)		// bit 2
#define TX_WORD_COMPLETE_BIT	(0x8)		// bit 3
#define TX_SPI_IDLE_BIT			(0x10)	// bit 4
#define TX_INTERRUPT_BIT		(0x80)	// bit 7

#define RX_FIFO_FULL_BIT		(0x10)	// bit 4
#define RX_FIFO_NOT_EMPTY		(0x20)	// bit 5
#define RX_BUFF_OVERRUN_BIT		(0x40)	// bit 6
#define RX_INTERRUPT			(0x80)	// bit 7

#define SPI_OK_CODE					(0x0)
#define SPI_RX_EMPTY_CODE			(0x1)
#define SPI_TX_SEND_PROBLEM_CODE	(0x2)

#define SPI_MAX_TRY		(100)
#define NB_DRIVERS_MAX  (2)

#define SPI_MAX_RETRY	(5)
    
/********************************************************
*				FUNCTIONS DECLARATION
********************************************************/
    
void spiInit();

uint8_t spiWriteVal(uint8_t channel, uint16_t value);
uint8_t spiReadValue(uint16_t * value);

// Writes data to SPI and reads returned data
uint16_t spiReadWriteReg(uint8_t chipSelect, uint16_t data);

bool spiEmptyRxBuffer();


#endif	// __SPI_H__
